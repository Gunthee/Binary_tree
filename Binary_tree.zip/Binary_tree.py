#structure
class Node:
    def __init__(self,data):
        self.left = None
        self.right = None
        self.data = data
         

    def insert(self,data):
        if self.data is None:
            self.data = data 
        else:
            if data < self.data:
                if self.left is None:
                    self.left = Node(data)
                else:
                    self.left.insert(data)
            elif data > self.data:
                if self.right is None:
                    self.right = Node(data)
                else:
                    self.right.insert(data)
                    
# insert data
list = [50,25,75,30,60,40,35,70,90,15,45,27,55,85,100,32,96] 

root = Node(list[0])

for i in list:
    root.insert(i)
print(f'insert value:{list}')

#print in-ordder (Infix): left, root, right
print('inorder')
def inorder(r):
    if r is None:
        return
    else:
        inorder(r.left)   #left
        print(r.data)     #root
        inorder(r.right)  #right 
#print(inorder(root))

#pre-order (Prefix): root, left ,right
print('Pre Order')
def preorder(s):
    if s is None:
        return
    else:
        print(s.data)        #root
        preorder(s.left)     #left
        preorder(s.right)     #right
print(preorder(root))

#Postorder (Postfix): left, right, root
print('Postorder')
def postorder(t):
    if t is None:
        return
    else:
        postorder(t.left) #left
        postorder(t.right) #right
        print(t.data)      #root 
        
print(postorder(root))



